# 12 Beers of Christmas 🍺🎄

A small web app for 12 friends drinking one beer a day from **December 13 to December 24**. Each person picks their name, logs in with a 4-digit PIN, and answers a few questions about that day's beer. The group sees each other's beers, a leaderboard, and the top-rated beers.

Everything runs on **Netlify**. Answers are stored as JSON in **Netlify Blobs**, Netlify's built-in storage, which is included free. You don't need another database or account.

```
12-beers/
├── config.json               ← names and dates (edit this)
├── public/index.html         ← the app people see
├── netlify/functions/api.mjs ← saves and loads answers, checks PINs
├── netlify.toml              ← tells Netlify where things are
└── package.json
```

---

## 1. Put in your 12 names

Open `config.json` in any text editor and replace `"Person 1"` … `"Person 12"` with real names. Keep the quotes and commas:

```json
"participants": [
  "Mike", "Sarah", "Dave", "Jen",
  ...
]
```

`year` and `firstDay` (13 = Day 1 is Dec 13) are already set for 2026.

> Set the names **before** you share the link. If you rename someone after they've set a PIN, they'll have to start over.

## 2. Deploy to Netlify

⚠️ **Don't use Netlify's drag-and-drop ("Netlify Drop") page.** It only publishes static files and won't run the part that saves answers. Use one of the two options below instead.

### Option A: through GitHub (no installs, all in the browser)

1. Create a free account at https://github.com, click **+ → New repository**, name it `12-beers`, and click **Create repository**.
2. On the new repo page, click **uploading an existing file**. Drag in **everything inside** the `12-beers` folder, including the `netlify` and `public` folders. Click **Commit changes**.
   (GitHub may hide `.gitignore`. That's fine.)
3. Go to https://app.netlify.com → **Add new site → Import an existing project → GitHub**, authorize it, and pick your `12-beers` repo.
4. Leave every setting as it is (Netlify reads `netlify.toml`) and click **Deploy**.
5. After about a minute you'll have a live link. To rename it, go to **Site configuration → Change site name** (e.g. `12-beers-2026`).

To change something later, edit the file on GitHub (pencil icon → **Commit**). Netlify redeploys automatically and keeps everyone's answers.

### Option B: with the Netlify command line (if you have Node.js installed)

```bash
cd 12-beers
npm install
npx netlify-cli login
npx netlify-cli deploy --prod
```

Follow the prompts to create a new site.

## 3. Set your organizer key (for PIN resets and exports)

1. In Netlify, open your site → **Site configuration → Environment variables → Add a variable**.
2. Key: `ADMIN_KEY`. Value: any password you'll remember. **Create**.
3. Go to **Deploys → Trigger deploy → Deploy site** so the key takes effect.

Your organizer page is your site's address followed by **`#admin`**, e.g. `https://12-beers-2026.netlify.app/#admin`. From there you can:
- **Download all answers** as one JSON file
- **Reset a forgotten PIN** (their beers are kept)
- **Start fresh**, which deletes all PINs and beers (use this after testing)

## 4. Test it, then share

1. To try it before Dec 13, set `"unlockAllDays": true` in `config.json` and redeploy. Every door opens.
2. Log in as a couple of people, log some beers, and check the leaderboard.
3. Set `"unlockAllDays": false` and redeploy. Then go to `#admin` → **Start fresh** to clear your test data.
4. Send the link to the group 🎉

**Quick preview:** double-clicking `public/index.html` on your computer opens a **demo mode**. It saves only in that browser, so it's handy for checking the look, but nothing is shared.

---

## Good to know

- **When do days open?** At midnight on each date, by each person's own phone clock.
- **Missed a day?** Any day that has opened can be logged or edited anytime.
- **Seeing others' answers:** you see the group's ratings for a day only after you've logged your own, so nobody gets swayed.
- **Updates:** the app refreshes every 30 seconds and whenever you switch back to it.
- **PIN security:** PINs are checked on the server and stored scrambled, and 5 wrong tries locks that name for 10 minutes. It's good protection for a group of friends, but still only 4 digits, so don't reuse an important PIN.
- **Cost:** a 12-person app fits easily within Netlify's free plan.
