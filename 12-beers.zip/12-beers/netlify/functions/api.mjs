// 12 Beers of Christmas: the whole back end.
// Data is stored as JSON in Netlify Blobs (Netlify's built-in storage):
//   users/<id>    -> { name, salt, pinHash, fails, lockedUntil }
//   entries/<id>  -> { "1": {...day 1 entry...}, "2": {...}, ... }
//   meta/secret   -> random key used to sign login tokens
import { getStore } from "@netlify/blobs";
import { scryptSync, randomBytes, createHmac, timingSafeEqual } from "node:crypto";
import settings from "../../config.json" with { type: "json" };

const slug = n => String(n).toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "user";
const PEOPLE = new Map(settings.participants.map(p => [slug(p), p]));
const STYLES_MAX = 40, TEXT_MAX = 80, NOTES_MAX = 500;

const json = (data, status = 200, extra = {}) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...extra } });
const fail = (status, error) => json({ error }, status);
const db = () => getStore({ name: "twelve-beers", consistency: "strong" });

const hashPin = (pin, salt) => scryptSync(String(pin), salt, 32).toString("hex");
const same = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y); };

async function secret(s) {
  let k = await s.get("meta/secret");
  if (!k) { k = randomBytes(32).toString("hex"); await s.set("meta/secret", k); }
  return k;
}
// The token changes automatically if the person's PIN is reset.
const makeToken = (key, id, u) => createHmac("sha256", key).update(`${id}:${u.pinHash}`).digest("hex");

// Days open at local midnight for the person; the server allows up to 14 h early to cover time zones.
function dayOpen(d) {
  if (settings.unlockAllDays) return true;
  return Date.now() >= Date.UTC(settings.year, 11, settings.firstDay + d - 1) - 14 * 3600e3;
}

const clip = (v, n) => String(v ?? "").trim().slice(0, n);

async function readBody(req) { try { return await req.json(); } catch { return {}; } }

async function allEntries(s) {
  const { blobs } = await s.list({ prefix: "entries/" });
  const lists = await Promise.all(blobs.map(b => s.get(b.key, { type: "json" })));
  return lists.flatMap(obj => Object.values(obj || {}));
}

async function checkToken(s, id, token) {
  if (!PEOPLE.has(id) || !token) return false;
  const u = await s.get(`users/${id}`, { type: "json" });
  if (!u) return false;
  return same(makeToken(await secret(s), id, u), String(token));
}

const isAdmin = req => {
  const key = process.env.ADMIN_KEY;
  return key && same(String(req.headers.get("x-admin-key") || ""), key);
};

export default async (req) => {
  const s = db();
  const route = new URL(req.url).pathname.replace(/^\/api\/?/, "");

  try {
    /* ---------- everything the app needs to draw itself ---------- */
    if (req.method === "GET" && route === "state") {
      const { blobs } = await s.list({ prefix: "users/" });
      return json({
        config: { year: settings.year, firstDay: settings.firstDay, unlockAllDays: !!settings.unlockAllDays, participants: settings.participants },
        registered: blobs.map(b => b.key.slice(6)),
        entries: await allEntries(s)
      });
    }

    /* ---------- log in, or set a PIN the first time ---------- */
    if (req.method === "POST" && route === "login") {
      const { user, pin, create } = await readBody(req);
      if (!PEOPLE.has(user)) return fail(400, "Unknown name.");
      if (!/^\d{4}$/.test(String(pin))) return fail(400, "PIN must be 4 digits.");
      const key = `users/${user}`;
      let u = await s.get(key, { type: "json" });

      if (!u) {
        if (!create) return fail(409, "This person hasn't set a PIN yet.");
        const salt = randomBytes(16).toString("hex");
        u = { name: PEOPLE.get(user), salt, pinHash: hashPin(pin, salt), fails: 0, createdAt: Date.now() };
        await s.setJSON(key, u);
      } else {
        if (create) return fail(409, "A PIN already exists for this name. Enter it to log in.");
        if (u.lockedUntil && Date.now() < u.lockedUntil) {
          const mins = Math.ceil((u.lockedUntil - Date.now()) / 60000);
          return fail(429, `Too many wrong PINs. Try again in ${mins} minute${mins > 1 ? "s" : ""}.`);
        }
        if (!same(hashPin(pin, u.salt), u.pinHash)) {
          u.fails = (u.fails || 0) + 1;
          if (u.fails >= 5) { u.fails = 0; u.lockedUntil = Date.now() + 10 * 60e3; }
          await s.setJSON(key, u);
          return fail(401, "That PIN doesn't match. Try again.");
        }
        if (u.fails || u.lockedUntil) { u.fails = 0; delete u.lockedUntil; await s.setJSON(key, u); }
      }
      return json({ token: makeToken(await secret(s), user, u) });
    }

    /* ---------- save (or update) one day's beer ---------- */
    if (req.method === "POST" && route === "entry") {
      const { user, token, entry = {} } = await readBody(req);
      if (!(await checkToken(s, user, token))) return fail(401, "Please log in again.");
      const day = Number(entry.day), rating = Number(entry.rating);
      if (!Number.isInteger(day) || day < 1 || day > 12) return fail(400, "Invalid day.");
      if (!dayOpen(day)) return fail(400, "That day hasn't opened yet.");
      if (!Number.isInteger(rating) || rating < 1 || rating > 5) return fail(400, "Rating must be 1–5 stars.");
      const beer = clip(entry.beer, TEXT_MAX);
      if (!beer) return fail(400, "Give your beer a name.");
      const abv = entry.abv === "" || entry.abv == null ? "" : Math.round(Number(entry.abv) * 10) / 10;

      const clean = {
        user, day, beer, rating,
        brewery: clip(entry.brewery, TEXT_MAX),
        style: clip(entry.style, STYLES_MAX),
        abv: Number.isFinite(abv) && abv >= 0 && abv <= 70 ? abv : "",
        notes: clip(entry.notes, NOTES_MAX),
        again: ["Yes", "Maybe", "No"].includes(entry.again) ? entry.again : "",
        updatedAt: Date.now()
      };
      const key = `entries/${user}`;
      const mine = (await s.get(key, { type: "json" })) || {};
      mine[day] = clean;
      await s.setJSON(key, mine);
      return json({ ok: true, entry: clean });
    }

    /* ---------- admin: reset someone's PIN (needs ADMIN_KEY) ---------- */
    if (req.method === "POST" && route === "admin/reset-pin") {
      if (!process.env.ADMIN_KEY) return fail(403, "Set ADMIN_KEY in Netlify's environment variables first.");
      if (!isAdmin(req)) return fail(403, "Wrong admin key.");
      const { user } = await readBody(req);
      if (!PEOPLE.has(user)) return fail(400, "Unknown name.");
      await s.delete(`users/${user}`);
      return json({ ok: true });
    }

    /* ---------- admin: wipe all PINs and entries (start fresh after testing) ---------- */
    if (req.method === "POST" && route === "admin/wipe") {
      if (!process.env.ADMIN_KEY) return fail(403, "Set ADMIN_KEY in Netlify's environment variables first.");
      if (!isAdmin(req)) return fail(403, "Wrong admin key.");
      const { confirm } = await readBody(req);
      if (confirm !== "WIPE") return fail(400, 'Type WIPE to confirm.');
      const keys = [...(await s.list({ prefix: "users/" })).blobs, ...(await s.list({ prefix: "entries/" })).blobs].map(b => b.key);
      await Promise.all(keys.map(k => s.delete(k)));
      return json({ ok: true, deleted: keys.length });
    }

    /* ---------- admin: download everything as one JSON file ---------- */
    if (req.method === "GET" && route === "admin/export") {
      if (!process.env.ADMIN_KEY) return fail(403, "Set ADMIN_KEY in Netlify's environment variables first.");
      if (!isAdmin(req)) return fail(403, "Wrong admin key.");
      const entries = (await allEntries(s))
        .map(e => ({ name: PEOPLE.get(e.user) || e.user, ...e }))
        .sort((a, b) => a.day - b.day || a.name.localeCompare(b.name, undefined, { numeric: true }));
      return json({ exportedAt: new Date().toISOString(), settings, entries }, 200,
        { "content-disposition": `attachment; filename="12-beers-${settings.year}.json"` });
    }

    return fail(404, "Not found.");
  } catch (err) {
    console.error(err);
    return fail(500, "Server error: " + err.message);
  }
};

export const config = { path: "/api/*" };
